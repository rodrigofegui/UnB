var class_inter_est =
[
    [ "consultar", "class_inter_est.html#a7bae3a060f9bd1ad151d0c0aefb5161d", null ],
    [ "consultar", "class_inter_est.html#acf23f0f0ad2c52c4dd26a1663d9ed7cf", null ],
    [ "criarResenha", "class_inter_est.html#aa47705a90b5a2e05f665d25b3e79c8ae", null ],
    [ "incluir", "class_inter_est.html#a1fbb528fcf5791335109049451e65227", null ],
    [ "remover", "class_inter_est.html#a78d9d82fc1ff8d4a94b0efab4e3b59c7", null ]
];