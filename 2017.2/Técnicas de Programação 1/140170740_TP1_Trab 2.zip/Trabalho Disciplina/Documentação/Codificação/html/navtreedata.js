var NAVTREE =
[
  [ "Trabalho_Disciplina", "index.html", [
    [ "Classes", "annotated.html", [
      [ "Lista de componentes", "annotated.html", "annotated_dup" ],
      [ "Índice dos componentes", "classes.html", null ],
      [ "Hierarquia de classes", "hierarchy.html", "hierarchy" ],
      [ "Componentes membro", "functions.html", [
        [ "Tudo", "functions.html", "functions_dup" ],
        [ "Funções", "functions_func.html", "functions_func" ],
        [ "Variáveis", "functions_vars.html", null ],
        [ "Enumerações", "functions_enum.html", null ]
      ] ]
    ] ],
    [ "Ficheiros", null, [
      [ "Lista de ficheiros", "files.html", "files" ],
      [ "Membros dos Ficheiros", "globals.html", [
        [ "Tudo", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_aut_8hpp.html",
"class_livro.html#a021671319eb46fba4b611bb8d0e01b81"
];

var SYNCONMSG = 'clique para desativar a sincronização do painel';
var SYNCOFFMSG = 'clique para ativar a sincronização do painel';