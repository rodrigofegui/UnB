var class_versao =
[
    [ "Versao", "class_versao.html#abe4df3db1fef14d133c0f98881fd0e9c", null ],
    [ "Versao", "class_versao.html#a5eff9a2b9d79349a0d5b657616444dc0", null ],
    [ "deletar", "class_versao.html#a2416e4e097c5fcdaf47d607303e79a2e", null ]
];