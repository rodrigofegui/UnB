var class_op_result =
[
    [ "OpResult", "class_op_result.html#ab79a4ad122277807e04343dd3158335c", null ],
    [ "OpResult", "class_op_result.html#a20d3d5ef38aeea10679599564486aba8", null ],
    [ "deletar", "class_op_result.html#a031c251e7ea301f433deb22eb64b35d4", null ]
];