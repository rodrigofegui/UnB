var class_inter_s_est =
[
    [ "consultar", "class_inter_s_est.html#a78e531e0601e01e86647c1568d88bbcf", null ],
    [ "consultar", "class_inter_s_est.html#ad10e1302f3ca151d4bdc2f54839e8297", null ],
    [ "criarResenha", "class_inter_s_est.html#a17c91a394a7aa8dad9ec00fd456a77c8", null ],
    [ "incluir", "class_inter_s_est.html#a43e54b33cdf858ea137b8005efb66f81", null ],
    [ "procurar", "class_inter_s_est.html#aae09a52d6d649980d6432f84bfb4fbd9", null ],
    [ "remover", "class_inter_s_est.html#ad7a358e00a5f1a150a3205270aa3c593", null ],
    [ "sinTroca", "class_inter_s_est.html#afaa591e3f50b533cc67379e7a9cfdcf3", null ]
];