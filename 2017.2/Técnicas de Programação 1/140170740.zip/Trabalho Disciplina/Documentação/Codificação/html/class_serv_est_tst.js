var class_serv_est_tst =
[
    [ "consultar", "class_serv_est_tst.html#ac45f05329833d5da86d4a1a8226f1088", null ],
    [ "consultar", "class_serv_est_tst.html#ae1fdb88bbdb9684acbbe1403c32c8cd7", null ],
    [ "criarResenha", "class_serv_est_tst.html#a3457793cbff23fca790a6b430ddcb112", null ],
    [ "incluir", "class_serv_est_tst.html#a8dd93126145173bb02a60231dec41a8d", null ],
    [ "procurar", "class_serv_est_tst.html#a588866907b793d1c971a24850f011158", null ],
    [ "remover", "class_serv_est_tst.html#a608c395f49b6a66c5e043de13eb25ce4", null ],
    [ "sinTroca", "class_serv_est_tst.html#a78034c13629c20479a6fd6bd5b4a0954", null ]
];