var class_a_cmd_sin_troca =
[
    [ "ACmdSinTroca", "class_a_cmd_sin_troca.html#a1d5c73e3a979dcbf60bd87112df2d5a8", null ],
    [ "ACmdSinTroca", "class_a_cmd_sin_troca.html#a27dd8ca1e0a25c234fe3603c4b55959e", null ],
    [ "ACmdSinTroca", "class_a_cmd_sin_troca.html#ad7cfaa2a639a187b57db88f121bb91bf", null ],
    [ "executar", "class_a_cmd_sin_troca.html#a263497d5575e6fd98f0c11f0177776bf", null ]
];