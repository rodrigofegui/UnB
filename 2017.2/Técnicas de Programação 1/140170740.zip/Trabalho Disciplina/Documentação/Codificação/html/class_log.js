var class_log =
[
    [ "Log", "class_log.html#af6071a60aa52b6c1b511f99b4bc1b8fe", null ],
    [ "Log", "class_log.html#a46203a026055f3a84611befdb2163a5f", null ],
    [ "Log", "class_log.html#a16adc5e36779c647c7afd0d3ef62defd", null ],
    [ "deletar", "class_log.html#a6d08cec3851f756b9cc64326936c06d5", null ]
];