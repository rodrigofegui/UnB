var class_login =
[
    [ "Login", "class_login.html#a4847f3e07e43b540d3339392346f87ff", null ],
    [ "Login", "class_login.html#a54a123d68d43402fb90d88ab9e9f265b", null ],
    [ "deletar", "class_login.html#aa7b544f68367982f93044100fc0275ec", null ],
    [ "equals", "class_login.html#a8816f8a2d26a48b219d208914e3bbc49", null ],
    [ "getApelido", "class_login.html#aa4490df2eb3b35e91e669b381969d9d8", null ],
    [ "getSenha", "class_login.html#ac9bd16f429183decbd17879167feab34", null ],
    [ "setApelido", "class_login.html#ace0e2e1c01bd0072768a73553a1cc97c", null ],
    [ "setSenha", "class_login.html#a8cd8c5f025017cd7963586e3dd06ba95", null ]
];