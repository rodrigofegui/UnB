var class_inter_cntrl =
[
    [ "construir", "class_inter_cntrl.html#a623219eaa77285ffc3ffafc997081361", null ],
    [ "escritaLog", "class_inter_cntrl.html#af458e028bccbbd0de5925b41cbd97acc", null ],
    [ "getArqLog", "class_inter_cntrl.html#ac44158710e7e622cf7993f5092e59257", null ],
    [ "setArqLog", "class_inter_cntrl.html#a893e46950c94f398e8319a300087db1d", null ]
];