var class_apelido =
[
    [ "Apelido", "class_apelido.html#ae428ec9dfc6690dce5afc27bef5cbb52", null ],
    [ "Apelido", "class_apelido.html#ac460405532ecb52ea80ec7c8b69ce709", null ],
    [ "deletar", "class_apelido.html#acf8895ee2c7ef835f81ef6edbf505bda", null ]
];