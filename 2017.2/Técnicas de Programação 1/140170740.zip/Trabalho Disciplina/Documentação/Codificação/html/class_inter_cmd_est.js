var class_inter_cmd_est =
[
    [ "executar", "class_inter_cmd_est.html#a2de50e2dd03729ba08e181b0bec7a205", null ],
    [ "getApelido", "class_inter_cmd_est.html#a3f71878556db8369f4701f349848f734", null ],
    [ "setApelido", "class_inter_cmd_est.html#ae733d7651e7f6ee4302d0efc69214d1f", null ],
    [ "apelido", "class_inter_cmd_est.html#a567135e193955f4847121e2a0a5c7da1", null ],
    [ "servico", "class_inter_cmd_est.html#a5e4444c18499c7d1b4f06e34ad293260", null ]
];