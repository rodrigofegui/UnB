var class_s_controle =
[
    [ "SControle", "class_s_controle.html#aba2948dc62f451fb6637a7971af093ca", null ]
];