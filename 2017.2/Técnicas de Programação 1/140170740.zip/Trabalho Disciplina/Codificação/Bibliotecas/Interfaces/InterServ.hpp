#ifndef INTER_SERV_HPP
    #define INTER_SERV_HPP

    /**
     *  @file   InterServ.hpp
     *  @author Rodrigo F. Guimarães
     */
    #include <stdexcept>

    /**
     *  @class  InterServ
     *  Puramente para polimorfismo
     */
    class InterServ{};
#endif // INTER_SERV_HPP
